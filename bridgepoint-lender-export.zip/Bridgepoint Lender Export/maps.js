// Per-lender maps: which of the lender's screens we recognize, which package
// value goes in which field, and which document categories go in which upload
// slot. Built one lender at a time in a mapping session (staff logged in, test
// data only). A lender with no pages yet still gets the panel's copy-and-
// download view.
//
// Page shape:
//   { name, match: () => boolean,
//     fields: [ { label | selector (+index), value: "dotted.package.path" | (pkg)=>value, fmt?: money|pct|int|mdy|ymd|upper }
//             | { radioName | radioPrefix, value }        -- picks the radio whose value= matches
//             | { click: "css", index? }                  -- reveal-only buttons, never submit/sign/send
//             | { wait: ms } ],
//     uploads: [{ label, category | categories:[], slot: { label | selector } }] }
// Package paths: loan.*, property.*, borrower.entityName, borrower.guarantor.*, borrower.coGuarantor.*, trackRecord[], documents[]
(function () {
  const STATE_NAMES = { AL:"Alabama",AK:"Alaska",AZ:"Arizona",AR:"Arkansas",CA:"California",CO:"Colorado",CT:"Connecticut",DE:"Delaware",DC:"District Of Columbia",FL:"Florida",GA:"Georgia",HI:"Hawaii",ID:"Idaho",IL:"Illinois",IN:"Indiana",IA:"Iowa",KS:"Kansas",KY:"Kentucky",LA:"Louisiana",ME:"Maine",MD:"Maryland",MA:"Massachusetts",MI:"Michigan",MN:"Minnesota",MS:"Mississippi",MO:"Missouri",MT:"Montana",NE:"Nebraska",NV:"Nevada",NH:"New Hampshire",NJ:"New Jersey",NM:"New Mexico",NY:"New York",NC:"North Carolina",ND:"North Dakota",OH:"Ohio",OK:"Oklahoma",OR:"Oregon",PA:"Pennsylvania",RI:"Rhode Island",SC:"South Carolina",SD:"South Dakota",TN:"Tennessee",TX:"Texas",UT:"Utah",VT:"Vermont",VA:"Virginia",WA:"Washington",WV:"West Virginia",WI:"Wisconsin",WY:"Wyoming" };
  const stateName = (s) => STATE_NAMES[String(s || "").toUpperCase()] || "";
  // "123 Main St, Tampa, FL 33610" -> parts (guarantor home address is one string on our side).
  function splitAddr(a) {
    const t = String(a || "").replace(/,\s*(USA|US|United States)\s*$/i, "").trim();
    const m = /^(.*?),\s*([^,]+),\s*([A-Za-z]{2})\s*(\d{5})?/.exec(t);
    return m ? { street: m[1].trim(), city: m[2].trim(), state: m[3].toUpperCase(), zip: m[4] || "" } : { street: t, city: "", state: "", zip: "" };
  }
  const yr = (v) => (v == null || v === "" ? null : Math.round(Number(v) * 12));
  const isRental = (p) => /DSCR|Portfolio/i.test(p.loan.loanType || "");
  const isGuc = (p) => /Ground Up|Construction/i.test(p.loan.loanType || "");
  const isRtl = (p) => /Fix|Flip/i.test(p.loan.loanType || "");

  // ---------------- RCN Capital (BLN broker portal) ----------------
  // Mapped 2026-10-06 from the "Create New Loan" intake (one long wizard form,
  // #lenderIntakeForm). Field names are stable; rental rows carry a GUID suffix,
  // so those use name^= prefixes. Never touch "Email electronic authorization
  // to guarantor" or the submission-email checkbox -- the person decides.
  const RCN_EXP = (n) => (n == null ? null : n >= 30 ? "30+" : n >= 10 ? "10+" : n >= 5 ? "5+" : n >= 3 ? "3+" : n >= 1 ? "1+" : "0+");
  const RCN_PAGE = {
    name: "RCN application intake",
    match: () => !!document.getElementById("lenderIntakeForm"),
    fields: [
      { radioName: "haveSizer", value: () => "0" },
      { radioName: "havePricingID", value: () => "0" },
      // Broker officer = the file's LO (when RCN has them); processor = Erika.
      { name: "Broker officer", selector: '[name="brokerage[employee_id]"]', value: (p) => { const n = String(p.meta.loanOfficerName || "").toLowerCase(); const el = document.querySelector('[name="brokerage[employee_id]"]'); const o = el && n ? Array.from(el.options).find((x) => x.value && n.split(" ").every((w) => x.text.toLowerCase().includes(w.replace(/[^a-z]/g, "")))) : null; return o ? o.value : null; } },
      { name: "Broker processor", selector: '[name="brokerage[broker_processor_entity_id]"]', value: () => "Erika Trafny" },
      { radioName: "isPortfolio", value: (p) => (/Portfolio/i.test(p.loan.loanType || "") ? "yes" : "no") },
      { radioName: "loanProgram", value: (p) => (/Portfolio/i.test(p.loan.loanType || "") ? "LTRP" : isRental(p) ? "LTR" : /Bridge/i.test(p.loan.loanType || "") ? "STB" : isGuc(p) ? "GUC" : "RTL") },
      { wait: 400 },
      { radioName: "loanType", value: (p) => ({ purchase: "purchase", cashout: "refinance", ratetermrefi: "refinanceRateTerm" })[p.loan.transactionType || "purchase"] || "purchase" },
      { radioName: "exitStrat", value: (p) => { const e = String(p.loan.exitStrategy || "").toLowerCase(); return /sell|flip/.test(e) ? "sell" : /refi/.test(e) ? "refinance" : /hold|rent/.test(e) ? "hold" : (isRental(p) ? "hold" : "unsure"); } },
      // Borrower entity + primary guarantor
      { name: "Company name", selector: '[name="entityCompanyName"]', value: "borrower.entityName" },
      { name: "Entity type", selector: '[name="entityType"]', value: "borrower.entityType" },
      { name: "Guarantor email", selector: '[name="guarantorEmail"]', value: "borrower.guarantor.email" },
      { name: "Guarantor phone", selector: '[name="guarantorPhone"]', value: (p) => String(p.borrower.guarantor.phone || "").replace(/\D/g, "").slice(-10) },
      { name: "Guarantor first name", selector: '[name="guarantorFirstName"]', value: "borrower.guarantor.firstName" },
      { name: "Guarantor middle initial", selector: '[name="guarantorMiddleName"]', value: (p) => String(p.borrower.guarantor.middleName || "").slice(0, 1) },
      { name: "Guarantor last name", selector: '[name="guarantorLastName"]', value: "borrower.guarantor.lastName" },
      { name: "Citizenship", selector: '[name="guarantorCitizenship"]', value: (p) => ({ "US Citizen": "0", "Foreign National": "1", "Permanent Resident": "2" })[p.borrower.guarantor.citizenship] },
      { name: "Estimated FICO", selector: '[name="guarantorFICO"]', value: "borrower.guarantor.creditScore", fmt: "int" },
      { click: "#cantFindAddress", index: 0, when: (p) => !!p.borrower.guarantor.address },
      { name: "Guarantor street", selector: '[name="guarantorAddress"]', value: (p) => splitAddr(p.borrower.guarantor.address).street },
      { name: "Guarantor city", selector: '[name="guarantorCity"]', value: (p) => splitAddr(p.borrower.guarantor.address).city },
      { name: "Guarantor state", selector: '[name="guarantorState"]', value: (p) => stateName(splitAddr(p.borrower.guarantor.address).state) },
      { name: "Guarantor zip", selector: '[name="guarantorZip"]', value: (p) => splitAddr(p.borrower.guarantor.address).zip },
      // Property
      { name: "Property type", selector: '[name="propertyType"]', value: (p) => ({ "SFR": "6", "Duplex": "14", "2-4 Unit": "14", "Multifamily 5+": "9", "Mixed-Use": "8", "Condo": "2", "Townhome": "Townhome" })[p.property.propertyType] || "6" },
      { name: "Units", selector: '[name="howManyUnits"]', value: "property.units", fmt: "int" },
      { click: "#cantFindAddress", index: 1 },
      { name: "Property street", selector: '[name="propertyAddress"]', value: "property.street" },
      { name: "Property city", selector: '[name="propertyCity"]', value: "property.city" },
      { name: "Property state", selector: '[name="propertyState"]', value: (p) => stateName(p.property.state) },
      { name: "Property zip", selector: '[name="propertyZip"]', value: "property.zip" },
      { name: "Purchase price", selector: '[name="purchasePrice"]', value: "loan.purchasePrice", fmt: "money" },
      { name: "Payoff / existing debt", selector: '[name="payoffAmount"]', value: "loan.currentLoanBalance", fmt: "money" },
      { name: "As-is value", selector: '[name="propertyAsIsValue"]', value: (p) => p.loan.currentValue || p.loan.purchasePrice, fmt: "money" },
      { name: "Amount requested", selector: '[name="loanInfoAmountRequested"]', value: "loan.loanAmount", fmt: "money" },
      { name: "Loan term", selector: '[name="loanTerm"]', value: (p) => (isRental(p) ? "9" : ({ 9: "15", 12: "1", 18: "2" })[p.loan.termMonths] || "1") },
      { radioName: "renovationRadio", value: (p) => (isRental(p) ? null : (p.loan.rehabBudget > 0 ? "yes" : "no")) },
      { wait: 300 },
      { radioName: "nearbyExperience", value: (p) => (p.borrower.guarantor.experienceDeals > 0 ? "1" : (p.borrower.guarantor.experienceDeals === 0 ? "0" : null)) },
      { name: "Experience (sold/held)", selector: '[name="borrowerExperience"]', value: (p) => RCN_EXP(p.borrower.guarantor.experienceDeals) },
      { name: "Renovation experience", selector: '[name="borrowerRenovationExperience"]', value: (p) => RCN_EXP(p.borrower.guarantor.experienceDeals) },
      { name: "Target closing date", selector: '[name="targetClosingDate"]', value: "loan.closeDate", fmt: "ymd" },
      // Rental (DSCR) details -- per-property rows carry a GUID suffix
      { radioPrefix: "currentOccupancy_", value: (p) => (isRental(p) ? (/leased|occupied|yes/i.test(String(p.property.leaseStatus || p.property.occupied || "")) ? "leased" : "vacant") : null) },
      { radioPrefix: "leasingStrategy_", value: (p) => (isRental(p) ? "longTerm" : null) },
      { name: "Est. market rent", selector: '[name^="rentInfoEstimatedMonthlyRent_"]', value: (p) => (isRental(p) ? p.property.monthlyRent : null), fmt: "money" },
      { name: "Annual property tax", selector: '[name^="propertyAnnualTax_"]', value: (p) => yr(p.property.monthlyTaxes), fmt: "money" },
      { name: "Annual insurance", selector: '[name^="propertyAnnualInsurancePremium_"]', value: (p) => yr(p.property.monthlyInsurance), fmt: "money" },
      { name: "Annual HOA", selector: '[name^="rentInfoHOAorPUD_"]', value: (p) => (p.property.monthlyHoa ? yr(p.property.monthlyHoa) : null), fmt: "money" },
      // Fix & flip
      { name: "Hard cost", selector: '[name="renovationHardCost"]', value: (p) => (isRtl(p) ? p.loan.rehabBudget : null), fmt: "money" },
      { name: "Renovation budget", selector: '[name="renovationBudget"]', value: (p) => (isRtl(p) ? p.loan.rehabBudget : null), fmt: "money" },
      { name: "Estimated ARV", selector: '[name="estimatedARV"]', value: (p) => (isRtl(p) ? p.loan.arv : null), fmt: "money" },
      // Ground up
      { name: "GUC hard costs", selector: '[name="GUCtotalHardCosts"]', value: (p) => (isGuc(p) ? p.loan.rehabBudget : null), fmt: "money" },
      { name: "GUC total construction cost", selector: '[name="GUCtotalConsCost"]', value: (p) => (isGuc(p) ? p.loan.rehabBudget : null), fmt: "money" },
      { name: "GUC as-built value", selector: '[name="GUCbuiltValue"]', value: (p) => (isGuc(p) ? p.loan.arv : null), fmt: "money" },
    ],
    uploads: [
      { label: "Purchase contract", category: "purchase_contract", slot: { selector: "#documentsFileUpload_purchase_contract_optional" } },
      { label: "Rehab list / scope of work", category: "scope_of_work", when: (p) => !isGuc(p), slot: { selector: "#documentsFileUpload_rehab_list_optional" } },
      { label: "Construction budget", category: "scope_of_work", when: (p) => isGuc(p), slot: { selector: "#documentsFileUpload_construction_budget_optional" } },
      { label: "Lease / rent roll", category: "leases_rent", slot: { selector: "#documentsFileUpload_lease_agreement_optional" } },
      { label: "Plans & permits", category: "construction_plans_permits", slot: { selector: "#documentsFileUpload_plans_optional" } },
      { label: "Borrower experience", category: "track_record", slot: { selector: "#documentsFileUpload_borrower_exp_optional" } },
      { label: "Title agent", categories: ["title_commitment", "cpl"], slot: { selector: "#documentsFileUpload_title_agent_optional" } },
      { label: "Credit authorization", category: "credit_authorization", slot: { selector: "#guarantorFileUpload" } },
      { label: "Additional (entity, ID, funds, insurance)", categories: ["entity_docs", "ein_letter", "good_standing", "entity_ownership", "photo_id", "proof_of_funds", "bank_statements", "insurance", "appraisal"], slot: { selector: "#documentsFileUpload_additional_optional" } },
    ],
  };

  // ---------------- Kiavi (app.kiavi.com broker app) ----------------
  // Mapped 2026-10-06 by walking a TEST draft (6abfaa41e3bf) up to the soft-credit-pull
  // screen. One question per screen; React widgets, so every page uses run().
  // Uses the FILE's own LLC + guarantor (Joe): an existing Kiavi entity profile with
  // the same name is reused, otherwise a new one is created.
  // Left for the person on purpose: the 3 eligibility attestations (citizenship,
  // non-occupancy, broker AML training) and the credit/background consent boxes.
  const kvPath = (re) => () => re.test(location.pathname);
  const KV_ENTITY_TYPE = { LLC: "Limited Liability Company", Corporation: "Corporation", Individual: "Sole Proprietor / Natural Person", "Limited Partnership": "Limited Partnership", Trust: "Statutory Trust" };
  const kvExp = (n) => (n == null ? null : n >= 5 ? "5" : n >= 3 ? "3" : n >= 1 ? "1" : "0");
  const kvFicoBand = (score) => (t) => {
    const m = /(\d{3})\s*-\s*(\d{3})/.exec(t); if (m) return score >= +m[1] && score <= +m[2];
    const p = /(\d{3})\s*\+/.exec(t); if (p) return score >= +p[1];
    const b = /(below|under|<)\s*(\d{3})/i.exec(t); if (b) return score < +b[2];
    return false;
  };
  const kvAddress = async (p, H, res, street, city, state, zip) => {
    const ok = await H.typeaheadPick(document.querySelector('[name="inputLine1"]'), street, city);
    if (!ok) { // fall back to typing each part
      H.setNative(document.querySelector('[name="inputLine1"]'), street);
      H.setNative(document.querySelector('[name="inputCity"]'), city || "");
      H.setNative(document.querySelector('[name="inputZip"]'), zip || "");
      const st = Array.from(document.querySelectorAll('input[id^="bedrock-select-input"]')).pop();
      await H.comboPick(st, stateName(state));
    }
    res.filled.push("address " + street + ", " + city);
  };
  const KIAVI_PAGES = [
    { name: "Kiavi: choose program", match: kvPath(/\/start\/choose-program/), run: async (p, H, res) => {
      const prog = /DSCR|Portfolio/i.test(p.loan.loanType || "") ? "rental" : /Ground Up|Construction/i.test(p.loan.loanType || "") ? "hard_money_infill" : "hard_money";
      const r = document.getElementById("program-" + prog); if (r) { H.realClick(r); r.click(); res.filled.push("program " + prog); } else res.missing.push("program");
    } },
    { name: "Kiavi: entity + guarantor", match: kvPath(/\/new-loan-application/), run: async (p, H, res) => {
      const g = p.borrower.guarantor || {}, ent = p.borrower.entityName || "";
      const sel = document.querySelector('input[id^="bedrock-select-input"]');
      const existing = ent && await H.comboPick(sel, (t) => H.norm(t).startsWith(H.norm(ent + " (Entity)")));
      if (existing) {
        res.filled.push("existing Kiavi entity: " + ent);
        // An existing entity then asks which guarantor: reuse theirs, or create the file's guarantor.
        await H.sleep(800);
        const gsel = Array.from(document.querySelectorAll('input[id^="bedrock-select-input"]')).filter((e) => e.offsetParent !== null)[1];
        const gname = [g.firstName, g.lastName].filter(Boolean).join(" ");
        const gotG = gsel && gname && await H.comboPick(gsel, (t) => H.norm(t).startsWith(H.norm(gname + " (Individual)")));
        if (gotG) res.filled.push("existing guarantor: " + gname);
        else if (gsel) { await H.comboPick(gsel, "-- Create New Guarantor --"); await H.sleep(600); res.filled.push("new guarantor"); }
      }
      else {
        await H.comboPick(sel, "-- Create New Entity --");
        await H.sleep(800);
        H.setNative(document.querySelector('[name="borrower.entityName"]'), ent || [g.firstName, g.lastName].filter(Boolean).join(" "));
        await H.comboPick(H.inputAfterLabel("Entity Type"), KV_ENTITY_TYPE[p.borrower.entityType] || "Limited Liability Company");
        res.filled.push("new entity " + ent);
      }
      const ex = kvExp(g.experienceDeals); const rr = ex && document.querySelector('input[name="exitsLast24"][value="' + ex + '"]'); if (rr) { H.realClick(rr); res.filled.push("experience"); }
      const fn = document.querySelector('[name="borrower.firstName"]'); if (fn && !fn.value) { H.setNative(fn, g.firstName || ""); H.setNative(document.querySelector('[name="borrower.lastName"]'), g.lastName || ""); res.filled.push("guarantor"); }
      if (await H.clickNav("Next")) res.filled.push("→ Next");
    } },
    { name: "Kiavi: property address", match: kvPath(/\/(pre-calc-)?property-address$/), run: async (p, H, res) => {
      const l1 = document.querySelector('[name="inputLine1"]');
      if (!l1 || !l1.value) await kvAddress(p, H, res, p.property.street, p.property.city, p.property.state, p.property.zip);
      if (await H.clickNav("Next")) res.filled.push("→ Next");
    } },
    { name: "Kiavi: rate calculator", match: kvPath(/\/rate-calculator\/[^/]+\/hard-money/), run: async (p, H, res) => {
      const L = p.loan, P = p.property, g = p.borrower.guarantor || {};
      const refi = L.transactionType && L.transactionType !== "purchase";
      const set = (label, v) => { const i = H.inputAfterLabel(label); if (i && v != null && v !== "") { H.setNative(i, String(Math.round(Number(v)))); res.filled.push(label); } else res.missing.push(label); };
      await H.comboPick(H.inputAfterLabel("Property Type"), ({ "SFR": "Single Family", "Condo": "Condo", "Townhome": "Townhome", "2-4 Unit": "2-4", "Duplex": "2-4" })[P.propertyType] || "Single Family");
      if (g.creditScore) await H.comboPick(H.inputAfterLabel("Est. FICO Score"), kvFicoBand(Number(g.creditScore)));
      await H.comboPick(H.inputAfterLabel("Refinance"), refi ? "Yes" : "No");
      if (refi) { res.missing.push("refinance fields — check by hand"); }
      else {
        const rehab = Number(L.rehabBudget || 0);
        set("Purchase Price", L.purchasePrice);
        set("Purchase Loan Amount", L.loanAmount ? Math.max(0, Number(L.loanAmount) - rehab) : null); // day-one amount
        await H.comboPick(H.inputAfterLabel("Property Rehab"), rehab > 0 ? "Yes" : "No");
        if (rehab > 0) { set("Estimated Cost of Rehab", rehab); await H.comboPick(H.inputAfterLabel("Rehab Funds"), "Yes"); }
        set("After Repair Value (ARV)", L.arv || L.purchasePrice);
      }
      const bp = document.querySelector('[name="brokerOriginationPoints"]'); if (bp && L.pointsCharged != null) { H.setNative(bp, String(Math.min(3, Number(L.pointsCharged)))); res.filled.push("broker points"); }
      await H.sleep(2500);
      // Pick the loan row for the file's term (12/18/24 months).
      const term = (L.termMonths && [12, 18, 24].includes(Number(L.termMonths))) ? L.termMonths : 12;
      const btn = Array.from(document.querySelectorAll("button")).filter((b) => b.offsetParent !== null && /^Choose$/i.test(b.innerText.trim())).find((b) => { let c = b; for (let i = 0; i < 6 && c; i++) { c = c.parentElement; if (c && new RegExp("\\b" + term + " Months").test(c.innerText) && (c.innerText.match(/Months/g) || []).length === 1) return true; } return false; });
      if (btn) { H.realClick(btn); res.filled.push("chose " + term + "-month option"); } else res.missing.push("loan option for " + term + " months — pick it by hand");
    } },
    { name: "Kiavi: eligibility confirmations", match: kvPath(/\/eligibility-confirmations$/), run: async (p, H, res) => {
      res.missing.push("Check the 3 confirmations yourself (citizenship, non-occupancy, AML training), then Next");
    } },
    { name: "Kiavi: signing date", match: kvPath(/\/preferred-signing-date$/), run: async (p, H, res) => {
      const d = document.querySelector('[name="borrowerRequestedDateSigning"]');
      const iso = p.loan.closeDate; if (d && iso) { const [y, m, dd] = String(iso).slice(0, 10).split("-"); H.setNative(d, m + "/" + dd + "/" + y); res.filled.push("signing date"); if (await H.clickNav("Next")) res.filled.push("→ Next"); }
      else res.missing.push("signing date (no target close date on the file)");
    } },
    { name: "Kiavi: primary contact", match: kvPath(/\/broker-primary-contact$/), run: async (p, H, res) => {
      const y = document.querySelector('input[name="basic"][value="yes"]'); if (y) { H.realClick(y); res.filled.push("broker is primary contact"); }
      if (await H.clickNav("Next")) res.filled.push("→ Next");
    } },
    { name: "Kiavi: credit pull info", match: kvPath(/\/combined-confirmations$/), run: async (p, H, res) => {
      const g = p.borrower.guarantor || {};
      const em = document.querySelector('[name="inputEmail"]'); if (em && g.email) { H.setNative(em, g.email); res.filled.push("email"); }
      const dob = document.querySelector('[name="inputDateOfBirth"]'); if (dob && g.dateOfBirth) { const [y, m, d] = String(g.dateOfBirth).slice(0, 10).split("-"); H.setNative(dob, m + "/" + d + "/" + y); res.filled.push("date of birth"); }
      const a = splitAddr(g.address); if (a.street) await kvAddress(p, H, res, a.street, a.city, a.state, a.zip);
      res.missing.push("Check the credit + background consent boxes (borrower signed our credit authorization), then Next — this runs Kiavi's soft pull");
    } },
  ];

  // ---------------- A&D Mortgage (aim.admortgage.com) ----------------
  // Mapped 2026-10-07 on AIM's live "Create New Loan" screen. A&D starts a loan from a
  // MISMO 3.4 upload; the package carries one generated server-side (no SSN). AIM reads
  // borrower name, loan amount and subject address from it (verified with TEST data).
  // The person reviews and clicks AIM's "Upload MISMO" -- that is what creates the loan.
  const AD_PAGES = [
    { name: "A&D: new loan (MISMO upload)", match: () => /^\/loan\/new/.test(location.pathname), run: async (p, H, res) => {
      const inp = document.querySelector('input[type="file"][accept*="xml"]');
      if (!p.mismo || !p.mismo.xml) { res.missing.push("MISMO file (not in the package — re-export from the CRM)"); return; }
      if (!inp) { res.missing.push("AIM's upload box (page changed?)"); return; }
      const dt = new DataTransfer();
      dt.items.add(new File([p.mismo.xml], p.mismo.fileName || "Bridgepoint-MISMO34.xml", { type: "text/xml" }));
      inp.files = dt.files; inp.dispatchEvent(new Event("change", { bubbles: true }));
      res.uploaded.push("MISMO 3.4 loan file");
      await H.sleep(5000);
      const texts = () => Array.from(document.querySelectorAll('input[type="text"]')).filter((i) => i.offsetParent !== null);
      const t = texts();
      if (t[0] && t[0].value) res.filled.push("borrower " + t[0].value + " " + ((t[1] && t[1].value) || "")); else res.missing.push("borrower name (AIM didn't read it — check the file)");
      if (t[2] && t[2].value) res.filled.push("loan amount " + t[2].value); else res.missing.push("loan amount");
      // AIM looks the address up live; if that comes back empty, type it into its address search.
      const addrIn = t[3];
      if (addrIn && !addrIn.value && p.property.street) {
        const ok = await H.typeaheadPick(addrIn, p.property.street + ", " + (p.property.city || ""), p.property.city);
        (ok ? res.filled : res.missing).push("subject address" + (ok ? "" : " — pick it by hand"));
      } else if (addrIn && addrIn.value) res.filled.push("subject address");
      // Estimated closing date: the file's target close date when it has one.
      const close = t[4];
      if (close && p.loan.closeDate) { const [y, m, d] = String(p.loan.closeDate).slice(0, 10).split("-"); H.setNative(close, m + "/" + d + "/" + y); res.filled.push("estimated closing date"); }
      else res.missing.push("estimated closing date — AIM defaulted it, confirm it");
      res.missing.push("Review, then click AIM's \"Upload MISMO\" to create the loan. Documents go in on the loan's Documents tab (use the panel's attach buttons).");
    } },
  ];

  // ---------------- Velocity Mortgage Capital (Generate Velocity broker portal) ----------------
  // Mapped 2026-10-14 on Tapia's real draft (loan 6723384190), AngularJS app with stable element ids. The borrower
  // screen (phase 2 > Additional Information) is where the application data goes: DOB, home address, marital status,
  // contact, rent/own, years, and the owned-properties list. NEVER touched: the SSN field, Save & Next, and anything
  // in phase 3 / Submit -- the person types the SSN and saves by hand. The owned-property address is a Google Places
  // box: we type it and try the keyboard pick; if Velocity doesn't take it, the panel says which one to click.
  const VEL_TYPE = { "Single Family": "Single Family Residence", "Condo / Townhome": "Single Family Condo", "2-4 Unit": "2-4 Unit Investment", "Multifamily 5+": "5+ Multi-Family Units", "Mixed-Use": "Mixed Use", "Commercial": "Other", "Land": "Other" };
  const VEL_PAGES = [
    { name: "Velocity: borrower information", match: () => /AppraisalNavigation\/AdditionalInformation/i.test(location.hash) && !!document.getElementById("DOB_0"),
      run: async (p, H, res) => {
        const S = window.BPFill;
        const g = p.borrower.guarantor || {};
        const byId = (id) => document.getElementById(id);
        const put = (id, v, name) => { const el = byId(id); if (v == null || v === "") { res.skipped.push(name || id); return; } if (el && S.setValue(el, String(v))) res.filled.push(name || id); else res.missing.push(name || id); };
        const home = splitAddr(g.homeAddress || g.address);
        put("DOB_0", S.FMT.mdy(g.dateOfBirth), "Date of birth");
        put("COEDate", S.FMT.mdy(p.loan.estClosingDate), "Estimated closing date");
        put("IsShortTermRental", p.property.shortTermRental, "Short-term rental");
        put("CurrentAddress", home.street, "Home street");
        put("City", home.city, "Home city");
        put("PrimaryState", stateName(home.state), "Home state");
        put("PostalCode", home.zip, "Home zip");
        put("ApplicantEmail_0", g.email, "Email");
        put("Marital_0", g.maritalStatus, "Marital status");
        put("Phone1_0", String(g.phone || "").replace(/\D/g, "").slice(-10), "Phone");
        put("PhoneType_0", g.phone ? "Mobile" : "", "Phone type");
        put("RentOrOwn1", g.ownRent, "Rent or own");
        put("NumberOfYears1", g.yearsAtAddress != null ? parseInt(g.yearsAtAddress, 10) : "", "Years at address");
        if (p.borrower.entityName && byId("Entity1") && document.querySelector('[name="Entity1"]')) { const en = document.querySelector('input[name="Entity1"]'); if (en && !en.value) { S.setValue(en, p.borrower.entityName); res.filled.push("Entity name"); } }
        // Other real estate owned (the SREO from the application).
        const owns = p.reoOwns === "Yes" ? "Yes" : p.reoOwns === "No" ? "No" : "";
        if (owns) {
          const sel = byId("RealEstateOwned");
          if (sel && S.setValue(sel, owns)) res.filled.push("Owns other real estate"); else res.missing.push("Owns other real estate");
        }
        const rows = owns === "Yes" ? (p.reo || []) : [];
        const q = (m, i) => Array.from(document.querySelectorAll('[ng-model="' + m + '"]'))[i];
        for (let i = 0; i < rows.length; i++) {
          await H.sleep(500);
          while (document.querySelectorAll('[ng-model="A.FullAddress"]').length < i + 1) {
            const b = Array.from(document.querySelectorAll("button")).find((x) => /^add an additional address$/i.test((x.innerText || "").trim()));
            if (!b) break; b.click(); await H.sleep(700);
          }
          const r = rows[i], tag = "Owned property " + (i + 1);
          const fa = q("A.FullAddress", i);
          if (!fa) { res.missing.push(tag + " (row not found)"); continue; }
          fa.focus(); H.setNative(fa, r.address || ""); fa.dispatchEvent(new Event("input", { bubbles: true }));
          await H.sleep(1800);
          // Keyboard pick of the first Google suggestion (a real click is sometimes the only thing Google accepts).
          const key = (k, c) => { const e = new KeyboardEvent("keydown", { key: k, bubbles: true, cancelable: true }); Object.defineProperty(e, "keyCode", { get: () => c }); Object.defineProperty(e, "which", { get: () => c }); fa.dispatchEvent(e); };
          key("ArrowDown", 40); await H.sleep(250); key("Enter", 13);
          let got = false;
          for (let t = 0; t < 8 && !got; t++) { await H.sleep(500); const s1 = q("A.Address1", i); got = !!(s1 && s1.value); }
          (got ? res.filled : res.missing).push(got ? tag + " address" : tag + ": click Google's suggestion under Full Address (" + r.address + ")");
          const ty = q("A.PropertyType", i); if (ty && r.propertyType && S.setValue(ty, VEL_TYPE[r.propertyType] || "Other")) res.filled.push(tag + " type");
          const val = q("A.PropertyEstimatedValue", i); if (val && r.currentValue != null && S.setValue(val, String(Math.round(r.currentValue)))) res.filled.push(tag + " value");
          const mo = q("A.ExistingMortgage", i); if (mo && r.loanBalance != null && S.setValue(mo, String(Math.round(r.loanBalance)))) res.filled.push(tag + " mortgage");
        }
        res.skipped.push("SSN (type it yourself)", "Save & Next (click it yourself)");
      } },
    // Phase 2 > Property Information: the borrower's own answers from our Property Questionnaire (declarations are never guessed).
    // The Current/Past/Proposed use and operations pickers are drop-down widgets: a person picks those.
    { name: "Velocity: property information", match: () => /AppraisalNavigation\/PropertyInformation/i.test(location.hash) && !!document.getElementById("YearOfConstruction"),
      run: async (p, H, res) => {
        const S = window.BPFill, a = p.propertyQuestionnaire;
        if (!a) { res.missing.push("Property questionnaire not completed by the borrower yet"); return; }
        const put = (id, v, name) => { const el = document.getElementById(id); if (v == null || v === "") { res.skipped.push(name || id); return; } if (el && S.setValue(el, String(v))) res.filled.push(name || id); else res.missing.push(name || id); };
        const yn = (v) => (v === "Yes" ? "Yes" : v === "No" ? "No" : "");
        put("YearOfConstruction", a.yearBuilt, "Year of construction");
        put("NumOfBuildings", a.numBuildings, "Buildings");
        put("NumOfTotalUnits", a.totalUnits, "Total units");
        put("NumOfVacantUnits", a.vacantUnits, "Vacant units");
        put("NumOfCurrentUnits", a.occupiedUnits, "Occupied units");
        put("CrossStreets", a.crossStreets, "Cross streets");
        put("AreaDescription", a.areaDescription, "Owner-occupied area description");
        put("SiteSize", a.siteSize, "Site size"); put("SiteSizeUnits", a.siteSizeUnit || "Square feet", "Site size units");
        put("BuildingSize", a.buildingSize, "Building size");
        put("HasWaterSource", yn(a.waterSource), "Water source"); put("IsMunicipal", yn(a.municipal), "Municipality");
        put("IsWetlands", yn(a.wetlands), "Wetlands"); put("RepairsNeeded", yn(a.repairsNeeded), "Repairs needed");
        put("MultipleParcels", yn(a.multipleParcels), "Multiple parcels"); put("RecentSale", yn(a.recentSale), "Sold in 24 months");
        put("MarijOrAdultEnt", yn(a.marijuanaAdult), "Marijuana / adult use"); put("SubjRegulation", yn(a.rentRegulated), "Rent regulation");
        put("PollutionConditions", { not_known: "Not Known", known_nfa: "NFA", known_active: "active remediation" }[a.pollution], "Pollution conditions");
        put("EnvironmentAssessment", yn(a.envAssessment), "Environmental assessment"); put("IsContaminated", yn(a.contamination), "Contamination knowledge");
        put("DryCleanerOnSite", { none: "No dry cleaner", dropoff: "Drop off only", green: "green dry cleaning", perc: "perchloroethylene" }[a.dryCleaner], "Dry cleaner");
        put("HasStorageTank", yn(a.storageTank), "Storage tanks"); put("HasStorageTankRemoved", yn(a.storageTankRemoved), "Storage tanks removed");
        put("IsGenerator", yn(a.rcraGenerator), "RCRA generator"); put("HasOccupants", yn(a.occupantsRegulated), "Occupants handling regulated substances");
        put("HasPendingSuit", yn(a.pendingSuit), "Pending lawsuit"); put("IsDamage", yn(a.waterDamage), "Water damage / mold claims"); put("IsWaterPlant", yn(a.moldPlan), "Mold management plan");
        res.skipped.push("Current / past / proposed use + operations (pick in the drop-downs: borrower wrote: " + (a.currentUse || "—") + " / past: " + (a.pastUse || "—") + ")", "Save & Next (click it yourself)");
      } },
  ];

  window.BP_MAPS = {
    RCN: { host: /commerciallendingservicesllc\.com$/, pages: [RCN_PAGE] },
    Kiavi: { host: /kiavi\.com$/, pages: KIAVI_PAGES },
    "A&D": { host: /admortgage\.com$/, pages: AD_PAGES },
    Constructive: { host: /bplhub\.com$/, pages: [] }, // portal side panel (copy + attach); full map built on the next real Constructive file
    NextRes: { host: /nextres\.com$/, pages: [] },
    Velocity: { host: /generatevelocity\.com$/, pages: VEL_PAGES }, // borrower screen mapped 10/14/26 (loan 6723384190); loan details / docs screens still to map
    LEND: { host: /leapplenderportal\.com$/, pages: [] },
    HomeXpress: { host: /homexmortgage\.com$/, pages: [] },
    Dominion: { host: /loanpass\.io$/, pages: [] },
  };
})();
